#include <iostream>
using namespace std;
int main(){
    long long unsigned int n = 1;
    int a;
    cin>>a;
    n = n<<(a+1);
    n = n-2;
    cout<<n;
    return 0;

}
