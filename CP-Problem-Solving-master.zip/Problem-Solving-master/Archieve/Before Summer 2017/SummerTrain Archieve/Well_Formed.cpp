//============================================================================
// Name        : Well_Formed.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stack>
using namespace std;

stack<char> let, con;

bool islowerCaseValid(char s) {
	bool lower = 0;
	if (s >= 97 && s <= 122)
		lower = 1;

}



int main() {

	return 0;
}
